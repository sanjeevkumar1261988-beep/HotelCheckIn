﻿using CareerSphareAPI.Helpers;
using CareerSphareAPI.Models;
using ElightRecruitmentAPI.Helpers;
using ElightRecruitmentAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CareerSphareAPI.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [ApiVersion("1")]
    [Route("api/v1/employer")]
    [AllowAnonymous]
    public class EmployerController : Controller
    {
        private readonly ILogger<MainController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public IConfiguration _configuration;
        // private RegistrationHelper _reg;
        public EmployerController(ILogger<MainController> logger, IWebHostEnvironment webHostEnvironment, IConfiguration _cnf)
        {
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
            _configuration = _cnf;
            //_reg = register;
        }
        [HttpPost("Registration")]
        public async Task<IActionResult> Registration([FromBody] EmployerRegistration registerObj)
        {
            return await Employer.Registration(registerObj.fullName, registerObj.cname, registerObj.email, registerObj.mobile.ToString(), _logger, _webHostEnvironment);
        }
        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] Login _login)
        {
            //string tt=  _configuration.GetConnectionString("ConnectionStringName");
            return await Employer.Login(_login.email, _login.password, _logger, _webHostEnvironment);

        }
    }
}
