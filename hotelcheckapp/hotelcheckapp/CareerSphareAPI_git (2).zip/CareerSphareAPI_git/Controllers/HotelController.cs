﻿using CareerSphareAPI.Helpers;
using ElightRecruitmentAPI.Helpers;
using ElightRecruitmentAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CareerSphareAPI.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [ApiVersion("1")]
    [Route("api/v1/Hotel/")]
    [AllowAnonymous]
    public class HotelController : ControllerBase
    {
        private readonly ILogger<MainController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public IConfiguration _configuration;
        // private RegistrationHelper _reg;
        public HotelController(ILogger<MainController> logger, IWebHostEnvironment webHostEnvironment, IConfiguration _cnf)
        {
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
            _configuration = _cnf;
            //_reg = register; 
        }
        [HttpPost("HotelRegistration")]
        public async Task<IActionResult> InsertRegisteredUser([FromBody] HotelRegistrationInput registerObj)
        {
            return await HotelHelper.InsertRegisteredUser(registerObj.hName, registerObj.mobile, registerObj.email, _logger, _webHostEnvironment);
        }

        [HttpPost("HotelLogin")]
        public async Task<IActionResult> LoginRegisteredUser([FromBody] Login _login)
        {
            //string tt=  _configuration.GetConnectionString("ConnectionStringName");
            return await HotelHelper.LoginRegisteredUser(_login.email, _login.password, _logger, _webHostEnvironment);

        }
        [HttpPost("HotelChangePassword")]
        public async Task<IActionResult> ChangePassword([FromBody] HotelChangePassword _chpass)
        {
            //string tt=  _configuration.GetConnectionString("ConnectionStringName");
            return await HotelHelper.ChangePassword(_chpass.HId, _chpass.CurrentPassword, _chpass.password, _logger, _webHostEnvironment);

        }
    }
}
