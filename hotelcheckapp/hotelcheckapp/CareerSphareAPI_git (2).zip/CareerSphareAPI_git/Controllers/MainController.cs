﻿using CareerSphareAPI.Models;
using ElightRecruitmentAPI.Helpers;
using ElightRecruitmentAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;

namespace CareerSphareAPI.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [ApiVersion("1")]
    [Route("api/v1/")]
    [AllowAnonymous]
    public class MainController : ControllerBase
    {
        private readonly ILogger<MainController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public IConfiguration _configuration;
        // private RegistrationHelper _reg;
        public MainController(ILogger<MainController> logger, IWebHostEnvironment webHostEnvironment, IConfiguration _cnf)
        {
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
            _configuration = _cnf;
            //_reg = register;
        }
        [HttpPost("InsertRegisteredUser")]
        public async Task<IActionResult> InsertRegisteredUser([FromBody] RegistrationInput registerObj)
        {
            return await RegistrationHelper.InsertRegisteredUser(registerObj.fullName, registerObj.experience, registerObj.highestQualifiation, registerObj.email, registerObj.mobile.ToString(), _logger, _webHostEnvironment);
        }
        [HttpPost("LoginRegisteredUser")]
        public async Task<IActionResult> LoginRegisteredUser([FromBody] Login _login)
        {
            //string tt=  _configuration.GetConnectionString("ConnectionStringName");
            return await RegistrationHelper.LoginRegisteredUser(_login.email, _login.password, _logger, _webHostEnvironment);

        }
        [HttpPost("ChangePassword")]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePassword _chpass)
        {
            //string tt=  _configuration.GetConnectionString("ConnectionStringName");
            return await RegistrationHelper.ChangePassword(_chpass.UserId, _chpass.CurrentPassword, _chpass.password, _logger, _webHostEnvironment);

        }

        [HttpPost("GetSearchJobs")]
        public async Task<IActionResult> GetSearchJobs([FromBody] SearchJobsInput _searchjobs)
        {
            return await RegistrationHelper.GetSearchJobs(_searchjobs.SearchInput, _logger, _webHostEnvironment);
        }
        [HttpPost("GetAppliedJobs")]
        public async Task<IActionResult> GetAppliedJobs([FromBody] AppliedjobsInput _appliedjobs)
        {
            return await RegistrationHelper.GetAppliedJobs(_appliedjobs.UserId, _logger, _webHostEnvironment);
        }

        [HttpPost("GetSearchJobsDetails")]
        public async Task<IActionResult> GetSearchJobsDetails([FromBody] searchinputbyjobid _searchjobs)
        {
            return await RegistrationHelper.GetSearchJobByJobID(_searchjobs, _logger, _webHostEnvironment);
        }

        [HttpPost("InsertJobApplications")]
        public async Task<IActionResult> InsertJobApplications([FromBody] JobApplicationInput _jobApp)
        {
            return await RegistrationHelper.InsertJobApplications(_jobApp, _logger, _webHostEnvironment);
        }
        [HttpPost("ResetPassword")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPassword _resp)
        {
            return await RegistrationHelper.ResetPassword(_resp, _logger, _webHostEnvironment);
        }
        [HttpPost("GetAutoCompleteSearch")]
        public async Task<IActionResult> GetAutoCompleteSearch([FromBody] SearchJobsInput _searchjobs)
        {
            return await RegistrationHelper.GetAutoCompleteSearch(_searchjobs, _logger, _webHostEnvironment);
        }

        [HttpPost("GetUserDetails")]
        public async Task<IActionResult> GetUserDetails([FromBody] updateUserInput userinputobj)
        {
            return await RegistrationHelper.GetUserDetails(userinputobj, _logger, _webHostEnvironment);
        }

        
        [HttpPost("UpdateUserDetails")]
        public async Task<IActionResult> UpdateUserDetails([FromBody] updateuserbasicdetails userinputobj)
        {
            return await RegistrationHelper.UpdateUserDetails(userinputobj, _logger, _webHostEnvironment);
        }

        [HttpPost("Upload")]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            Updateprofilepic _basicdata=new Updateprofilepic();

            clsuserid _objuserdetails = new clsuserid();
            _objuserdetails.UserId= file.FileName.Split('.')[0];

            var _resultpp =   await RegistrationHelper.GetUserprofilepic(_objuserdetails, _logger, _webHostEnvironment);

            List<getuserprofilepic> obj=_resultpp.Value as List<getuserprofilepic>;
           string imagePath = Path.Combine(_webHostEnvironment.WebRootPath, "UserProfilePhoto", obj[0].Profilephoto);
            try
            {
                if (System.IO.File.Exists(imagePath))
                {
                    System.IO.File.Delete(imagePath); // Delete the file
                    //return true; // Indicate success
                }
            }
            catch(Exception ex)
            {
                imagePath = ex.Message;
            }

            if (file == null || file.Length == 0)
            {
                return BadRequest("No file uploaded.");
            }

            var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "UserProfilePhoto");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var filePath = Path.Combine(uploadsFolder, file.FileName);
            _basicdata.UserId = file.FileName.Split('.')[0];
            _basicdata.pphoto = file.FileName;



            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var _result= await RegistrationHelper.UpdateUserDetailsprofilepic(_basicdata, _logger, _webHostEnvironment);

            return Ok(new { output = _result });
        }

        [HttpPost("UploadResume")]
        public async Task<IActionResult> UploadResume(IFormFile file)
        {
            Updateprofilepic _basicdata = new Updateprofilepic();

            clsuserid _objuserdetails = new clsuserid();
            _objuserdetails.UserId = file.FileName.Split('.')[0];

            var _resultpp = await RegistrationHelper.GetUserresume(_objuserdetails, _logger, _webHostEnvironment);

            List<getuserprofilepic> obj = _resultpp.Value as List<getuserprofilepic>;
            string imagePath = Path.Combine(_webHostEnvironment.WebRootPath, "UserResume", obj[0].Profilephoto);
            try
            {
                if (System.IO.File.Exists(imagePath))
                {
                    System.IO.File.Delete(imagePath); // Delete the file
                    //return true; // Indicate success
                }
            }
            catch (Exception ex)
            {
                imagePath = ex.Message;
            }

            if (file == null || file.Length == 0)
            {
                return BadRequest("No file uploaded.");
            }

            var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "UserResume");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var filePath = Path.Combine(uploadsFolder, file.FileName);
            _basicdata.UserId = file.FileName.Split('.')[0];
            _basicdata.pphoto = file.FileName;



            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var _result = await RegistrationHelper.UpdateUserresume(_basicdata, _logger, _webHostEnvironment);

            return Ok(new { output = _result });
        }


        [HttpPost("UpdateUserBasicDetails")]
            public async Task<IActionResult> UpdateUserBasicDetails([FromBody] updateuserbasicdetails userinputobj)
            {
                return await RegistrationHelper.UpdateUserDetails(userinputobj, _logger, _webHostEnvironment);
            }
            [HttpGet("{imageName}")]
            public IActionResult GetImage(string imageName)
            {
                var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/UserProfilePhoto", imageName);
                if (!System.IO.File.Exists(path))
                    return NotFound();

                var image = System.IO.File.OpenRead(path);
                return File(image, "image/jpeg"); // Or image/png, etc.
            }
        [HttpGet("download/{fileName}")]
        public IActionResult Downloadresume(string fileName)
        {
            var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/UserResume", fileName);
            if (!System.IO.File.Exists(path))
                return NotFound();

            string content = GetContentType(fileName);
            var fileout = System.IO.File.OpenRead(path);

            return File(fileout, content, fileName); // Or image/png, etc.
        }
        private string GetContentType(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            string contentType;

            if (!provider.TryGetContentType(fileName, out contentType))
            {
                // Fallback to a default content type if the provider cannot determine it
                contentType = "application/octet-stream";
            }

            return contentType;
        }

        [HttpPost("Updatelinkedinurl")]
        public async Task<IActionResult> Updatelinkedinurl([FromBody] LinkedInURL objlinkedinurl)
        {
            return await RegistrationHelper.Updatelinkedinurl(objlinkedinurl, _logger, _webHostEnvironment);
        }
        [HttpPost("GetProfileSummary")]
        public async Task<IActionResult> GetProfileSummary([FromBody] clsuserid objuid)
        {

            return await RegistrationHelper.GetProfileSummary(objuid, _logger, _webHostEnvironment);
        }
        [HttpPost("updateProfileSummary")]
        public async Task<IActionResult> updateProfileSummary([FromBody] GetCuuCompanydetails objuid)
        {
            return await RegistrationHelper.UpateProfileSummary(objuid, _logger, _webHostEnvironment);
        }                                                                                                                                                                                                                                                                                                                                                                                   
        [HttpPost("GETInterviewDetails")]
        public async Task<IActionResult> GETInterviewDetails([FromBody] clsuserid objuid)
        {

            return await RegistrationHelper.GETInterviewDetails(objuid, _logger, _webHostEnvironment);
        }
        [HttpPost("UpdateInterviewStatus")]
        public async Task<IActionResult> UpdateInterviewStatus([FromBody] UpdateInterviewstatus objuid)
        {

            return await RegistrationHelper.UpdateInterviewStatus(objuid, _logger, _webHostEnvironment);
        }
        
    }
}
