﻿using System.Data;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Text.RegularExpressions;
using ElightRecruitmentAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace ElightRecruitmentAPI.Helpers
{
    public class JobsServicesHelper
    {
        //private static string _Connstring = Globals._webconnstring;
        //private static  IWebHostEnvironment _env;


        public static async Task<ObjectResult> GetPaidServices(ILogger logger, IWebHostEnvironment _env)
        {
            try
            {
                logger.LogInformation("Getting Paid Services");
                List<Services> _ret = new List<Services>();

                using (SqlConnection cnn = new SqlConnection("Server=103.21.58.192;Initial Catalog=ElightRecruit;User ID=ElightRecruit_User;Password=ElightRecruit@#654;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_GetPaidServices", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new Services
                                {
                                    ServiceID = rdr.GetInt32(rdr.GetOrdinal("ServiceID")),
                                    ServiceName = rdr.GetString(rdr.GetOrdinal("ServiceName")).Trim(),
                                    DiscountInPercent = rdr.GetString(rdr.GetOrdinal("DiscountInPercent")).Trim(),                                   
                                    OldPrice = rdr.GetDecimal(rdr.GetOrdinal("OldPrice")),
                                    ActualPrice = rdr.GetDecimal(rdr.GetOrdinal("ActualPrice")),
                                    CGSTinPercent = rdr.GetString(rdr.GetOrdinal("CGSTinPercent")).Trim(),
                                    SGSTinPercent = rdr.GetString(rdr.GetOrdinal("SGSTinPercent")).Trim(),
                                    FinalPriceafterTax = rdr.GetDecimal(rdr.GetOrdinal("FinalPriceafterTax")),
                                    CurrencyType = rdr.GetString(rdr.GetOrdinal("CurrencyType")),

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }

        }

    }
}
