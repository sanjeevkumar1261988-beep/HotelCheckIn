﻿
using System.Text.RegularExpressions;
using ElightRecruitmentAPI.Models;
using Microsoft.Extensions.Options;
using MimeKit;
using MailKit.Net.Smtp;
using MailKit.Security;
using System.Net;
using System.Net.Mail;
using System.Reflection.PortableExecutable;

namespace ElightRecruitmentAPI.Helpers
{
    public static class Mailer
    {
        private static readonly MailSettings _mailSettings;
        private static readonly ConnStr _Conn;
        //public Mailer(IOptions<MailSettings> mailSettings, IOptions<ConnStr> DBconn)
        //{
        //    _mailSettings = mailSettings.Value;
        //    _Conn = DBconn.Value;
        //}

        public static void RegistrationMail(IWebHostEnvironment _envstring, string MailTo, string password)
        {
                var message = new MimeMessage();           
                message.From.Add(new MailboxAddress("Career Sphare", "marketing@careersphare.com"));
                message.To.Add(new MailboxAddress("", MailTo));
                message.Subject = "Welcome to Career Sphare";
                string htmlFilePath = _envstring.ContentRootPath + @"\\EmailTemplates\RegistrationSuccess.html";
                string htmlContent = File.ReadAllText(htmlFilePath);
                var bodyBuilder = new BodyBuilder
                {
                    //HtmlBody = htmlContent.Replace("@@email", MailTo).Replace("@@password", password)
                    HtmlBody = htmlContent

                };

                message.Body = bodyBuilder.ToMessageBody();


                Thread T1 = new Thread(delegate ()
                {
            
                    using (var smtp = new MailKit.Net.Smtp.SmtpClient())
                    {
                        //smtp.ServerCertificateValidationCallback = (s, c, h, e) => true;
                        smtp.Connect("smtpout.secureserver.net", 465, MailKit.Security.SecureSocketOptions.SslOnConnect);
                        smtp.Authenticate("marketing@careersphare.com", "MarketingCareer@#123");
                        smtp.Send(message);
                        smtp.Disconnect(true);
                    }
            
       
            
            });
                T1.Start();

            }


        public static async void PushEmailResetPassword(IWebHostEnvironment _env, string Email, string pass)
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("Career Sphare", "marketing@careersphare.com"));
            message.To.Add(new MailboxAddress("", Email));
            message.Subject = "Password Reset link for Career Sphare";
            string htmlFilePath = _env.ContentRootPath + @"\\EmailTemplates\ResetPassword.html";
            string htmlContent = File.ReadAllText(htmlFilePath);
            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = htmlContent.Replace("@@password", pass)

            };

            message.Body = bodyBuilder.ToMessageBody();


            Thread T1 = new Thread(delegate ()
            {

                using (var smtp = new MailKit.Net.Smtp.SmtpClient())
                {
                    //smtp.ServerCertificateValidationCallback = (s, c, h, e) => true;
                    smtp.Connect("smtpout.secureserver.net", 465, MailKit.Security.SecureSocketOptions.SslOnConnect);
                    smtp.Authenticate("marketing@careersphare.com", "MarketingCareer@#123");
                    smtp.Send(message);
                    smtp.Disconnect(true);
                }



            });
            T1.Start();
        }
    }
}
