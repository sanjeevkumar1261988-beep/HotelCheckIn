﻿using System.Data;
//using System.Net.Mail;
using System.Reflection;
using System.Text.RegularExpressions;
using ElightRecruitmentAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Hosting;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using System.Net;
using System.Text;
using CareerSphareAPI.Models;
namespace ElightRecruitmentAPI.Helpers
{

    public static class RegistrationHelper
    {
        //private static string _Connstring = Globals._webconnstring;
        //private static readonly string _ElightRecruitConn = "Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;";
        //private static Mailer _MailClass;


        public static async Task<ObjectResult> InsertRegisteredUser(string fullname, string totalexp, string higqual, string email, string mobile, ILogger logger, IWebHostEnvironment _env)
        {
            if (string.IsNullOrEmpty(fullname) || string.IsNullOrEmpty(higqual)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
           
            //var message = new MimeMessage();
            //message.From.Add(new MailboxAddress("sales", "sales@careersphare.com"));
            //message.To.Add(new MailboxAddress("sanjeev", "sanjeevkumar1261988@gmail.com"));
            //message.Subject = "Test Email from .NET Core";

            //message.Body = new TextPart("plain")
            //{
            //    Text = @"Hello, this is a test email sent using .NET Core and MailKit."
            //};
            //using (var smtp = new MailKit.Net.Smtp.SmtpClient())
            //{
            //    smtp.ServerCertificateValidationCallback = (s, c, h, e) => true;
            //    smtp.Connect("mail.careersphare.com", 587, MailKit.Security.SecureSocketOptions.StartTlsWhenAvailable);
            //    smtp.Authenticate("sales@careersphare.com", "2b1a&5I4c");
            //    smtp.Send(message);
            //    smtp.Disconnect(true);
            //}

           

            var DBoutput = await InsertRegisteredUserDB(fullname, totalexp, higqual, email, mobile, logger, _env);


            if (DBoutput.StatusCode == 200)
            {
                List<RegisterRes> _outputDB = (List<RegisterRes>)DBoutput.Value;
                if (_outputDB[0].UserId != 0)
                {

                    Mailer.RegistrationMail(_env, email, _outputDB[0].password);
                }
            }


            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };

        }

        public static async Task<ObjectResult> LoginRegisteredUser(string UserId, string Password, ILogger logger, IWebHostEnvironment _env)
        {
            if (string.IsNullOrEmpty(UserId) || string.IsNullOrEmpty(Password)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await ValidateUserIdPassword(UserId, Password, logger, _env);
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }

        public static async Task<ObjectResult> ChangePassword(string UserId, string Password, string NewPassword, ILogger logger, IWebHostEnvironment _env)
        {
            if (string.IsNullOrEmpty(Password)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await ChangePasswordDB(UserId, Password, NewPassword, logger, _env);
            //if (DBoutput.StatusCode == 200 && Password !="R")
            //{
            //    List<ResetPassRes> _outputDB = (List<ResetPassRes>)DBoutput.Value;
            //    if (_outputDB[0].Status != 0)
            //    {

            //        Mailer.PushEmailResetPassword(_env, _outputDB[0].EmailId, _outputDB[0].Password);
            //    }

            //}
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        public static async Task<ObjectResult> ResetPassword(ResetPassword _resp, ILogger logger, IWebHostEnvironment _env)
        {
            if (string.IsNullOrEmpty(_resp.EmailId)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await ResetPasswordDB(_resp.EmailId, logger, _env);

            if (DBoutput.StatusCode == 200)
            {
                List<ResetPassRes> _outputDB = (List<ResetPassRes>)DBoutput.Value;
                if (_outputDB[0].Status != 0)
                {

                    Mailer.PushEmailResetPassword(_env, _outputDB[0].EmailId, _outputDB[0].Password);
                }

            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        public static async Task<ObjectResult> GetAutoCompleteSearch(SearchJobsInput _resp, ILogger logger, IWebHostEnvironment _env)
        {
            
            var DBoutput = await GetAutoCompleteSearchDB(_resp.SearchInput, logger, _env);

            if (DBoutput.StatusCode == 200)
            {
                List<autocompleteresponse> _outputDB = (List<autocompleteresponse>)DBoutput.Value;
            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        public static async Task<ObjectResult> GetUserDetails(updateUserInput _resp, ILogger logger, IWebHostEnvironment _env)
        {

            var DBoutput = await GetUserDetailsDB(_resp.UserId, logger, _env);

            if (DBoutput.StatusCode == 200)
            {
                List<updateuserRes> _outputDB = (List<updateuserRes>)DBoutput.Value;
            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }

        

             public static async Task<ObjectResult> GetUserresume(clsuserid _resp, ILogger logger, IWebHostEnvironment _env)
        {

            var DBoutput = await GetUserresumeDB(_resp.UserId, logger, _env);

            if (DBoutput.StatusCode == 200)
            {
                List<getuserprofilepic> _outputDB = (List<getuserprofilepic>)DBoutput.Value;
            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        public static async Task<ObjectResult> GetUserprofilepic(clsuserid _resp, ILogger logger, IWebHostEnvironment _env)
        {

            var DBoutput = await GetUserprofilepicDB(_resp.UserId, logger, _env);

            if (DBoutput.StatusCode == 200)
            {
                List<getuserprofilepic> _outputDB = (List<getuserprofilepic>)DBoutput.Value;
            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        public static async Task<ObjectResult> UpdateUserDetails(updateuserbasicdetails _resp, ILogger logger, IWebHostEnvironment _env)
        {

            var DBoutput = await UpdateUserDetailsDB(_resp, logger, _env);

            if (DBoutput.StatusCode == 200)
            {
                List<RegistraionResponse> _outputDB = (List<RegistraionResponse>)DBoutput.Value;
            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        
        public static async Task<ObjectResult> UpdateUserDetailsprofilepic(Updateprofilepic _resp, ILogger logger, IWebHostEnvironment _env)
        {

            var DBoutput = await UpdateUserDetailsppDB(_resp, logger, _env);

            if (DBoutput.StatusCode == 200)
            {
                List<RegistraionResponse> _outputDB = (List<RegistraionResponse>)DBoutput.Value;
            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }

        public static async Task<ObjectResult> UpdateUserresume(Updateprofilepic _resp, ILogger logger, IWebHostEnvironment _env)
        {

            var DBoutput = await UpdateUserresumeDB(_resp, logger, _env);

            if (DBoutput.StatusCode == 200)
            {
                List<RegistraionResponse> _outputDB = (List<RegistraionResponse>)DBoutput.Value;
            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }

        public static async Task<ObjectResult> GetSearchJobs(string SearchInput, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await SearchjobsDB(SearchInput, logger, _env);
            return new ObjectResult(DBoutput);
        }
        public static async Task<ObjectResult> GetAppliedJobs(string SearchInput, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await AppliedjobsDB(SearchInput, logger, _env);
            return new ObjectResult(DBoutput);
        }
        
        public static async Task<ObjectResult> GetSearchJobByJobID(searchinputbyjobid SearchInput, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await SearchjobsByJobIDDB(SearchInput, logger, _env);
            return new ObjectResult(DBoutput);
        }
        public static async Task<ObjectResult> InsertJobApplications(JobApplicationInput SearchInput, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await InsertJobApplicationsDB(SearchInput, logger, _env);
            return new ObjectResult(DBoutput);
        }
        public static async Task<ObjectResult> Updatelinkedinurl(LinkedInURL objurl, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await UpdatelinkedinurlDB(objurl, logger, _env);
            return new ObjectResult(DBoutput);
        }
        public static async Task<ObjectResult> GetProfileSummary(clsuserid objurl, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await GetProfileSummaryDB(objurl, logger, _env);
            return new ObjectResult(DBoutput);
        }
        public static async Task<ObjectResult> UpateProfileSummary(GetCuuCompanydetails objurl, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await UpdateProfileSummaryDB(objurl, logger, _env);
            return new ObjectResult(DBoutput);
        }

        public static async Task<ObjectResult> UpdateInterviewStatus(UpdateInterviewstatus objurl, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await UpdateInterviewStatusDB(objurl, logger, _env);
            return new ObjectResult(DBoutput);
        }
        
        public static async Task<ObjectResult> GETInterviewDetails(clsuserid objurl, ILogger logger, IWebHostEnvironment _env)
        {
            //if (string.IsNullOrEmpty(skillset) || string.IsNullOrEmpty(location) || string.IsNullOrEmpty(experiencestatus)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await GETInterviewDetailsDB(objurl, logger, _env);
            return new ObjectResult(DBoutput);
        }

        
             private static async Task<ObjectResult> GETInterviewDetailsDB(clsuserid objurl, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("get GETInterviewDetailsDB");
                List<interviewdetails> _ret = new List<interviewdetails>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_GETInterviewDetails", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.Parameters.Add(new SqlParameter("@linkedinurl", SqlDbType.NVarChar)).Value = objurl.linkedinurl;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = objurl.UserId;
                        //cmd.Parameters.Add(new SqlParameter("@flag", SqlDbType.NVarChar)).Value = objurl.Flag;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new interviewdetails
                                {
                                    RoleName = rdr.GetString(rdr.GetOrdinal("rolename")),
                                    InterviewId = rdr.GetInt32(rdr.GetOrdinal("InterviewId")),
                                    JobId = rdr.GetInt32(rdr.GetOrdinal("JobId")),
                                    Interviewstatus = rdr.GetString(rdr.GetOrdinal("Interviewstatus")),
                                    InterviewDate = rdr.GetString(rdr.GetOrdinal("InterviewDate")),
                                    InterviewLocation = rdr.GetString(rdr.GetOrdinal("InterviewLocation")),
                                    InterviewConfirmstatus = rdr.GetInt32(rdr.GetOrdinal("InterviewConfirmstatus")),
                                    Name = rdr.GetString(rdr.GetOrdinal("Name")),
                                    LogoName = rdr.GetString(rdr.GetOrdinal("LogoName"))
                                    

                                    
                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static async Task<ObjectResult> UpdateProfileSummaryDB(GetCuuCompanydetails objurl, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("UpdateProfileSummaryDB");
                List<OutputOnlyStatus> _ret = new List<OutputOnlyStatus>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_UpdateProfileSummary", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.Parameters.Add(new SqlParameter("@linkedinurl", SqlDbType.NVarChar)).Value = objurl.linkedinurl;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = objurl.UserId;
                        cmd.Parameters.Add(new SqlParameter("@rolename", SqlDbType.NVarChar)).Value = objurl.rolename;
                        cmd.Parameters.Add(new SqlParameter("@companyname", SqlDbType.NVarChar)).Value = objurl.companyname;
                        cmd.Parameters.Add(new SqlParameter("@stmonth", SqlDbType.Int)).Value = objurl.stmonth;
                        cmd.Parameters.Add(new SqlParameter("@styear", SqlDbType.Int)).Value = objurl.styear;
                        cmd.Parameters.Add(new SqlParameter("@ctc", SqlDbType.Decimal)).Value = objurl.ctc;
                        cmd.Parameters.Add(new SqlParameter("@noticeperiod", SqlDbType.NVarChar)).Value = objurl.noticeperiod;
                        cmd.Parameters.Add(new SqlParameter("@IndustryType", SqlDbType.NVarChar)).Value = objurl.IndustryType;
                        cmd.Parameters.Add(new SqlParameter("@EmploymentType", SqlDbType.NVarChar)).Value = objurl.EmploymentType;
                        cmd.Parameters.Add(new SqlParameter("@Descrition", SqlDbType.NVarChar)).Value = objurl.Descrition;
                        cmd.Parameters.Add(new SqlParameter("@psummary", SqlDbType.NVarChar)).Value = objurl.psummary;
                        cmd.Parameters.Add(new SqlParameter("@skills", SqlDbType.NVarChar)).Value = objurl.skills;
                        cmd.Parameters.Add(new SqlParameter("@Qualification", SqlDbType.NVarChar)).Value = objurl.Qualification;
                        cmd.Parameters.Add(new SqlParameter("@institute", SqlDbType.NVarChar)).Value = objurl.institute;
                        cmd.Parameters.Add(new SqlParameter("@passyear", SqlDbType.NVarChar)).Value = objurl.passyear;
                        cmd.Parameters.Add(new SqlParameter("@edutype", SqlDbType.NVarChar)).Value = objurl.edutype;
                        cmd.Parameters.Add(new SqlParameter("@preferedrole", SqlDbType.NVarChar)).Value = objurl.preferedrole;
                        cmd.Parameters.Add(new SqlParameter("@preferedlocation", SqlDbType.NVarChar)).Value = objurl.preferedlocation;
                        cmd.Parameters.Add(new SqlParameter("@rescountry", SqlDbType.NVarChar)).Value = objurl.rescountry;
                        cmd.Parameters.Add(new SqlParameter("@wpermit", SqlDbType.NVarChar)).Value = objurl.wpermit;
                        cmd.Parameters.Add(new SqlParameter("@nationality", SqlDbType.NVarChar)).Value = objurl.nationality;
                        cmd.Parameters.Add(new SqlParameter("@certname", SqlDbType.NVarChar)).Value = objurl.certname;
                        cmd.Parameters.Add(new SqlParameter("@certissueby", SqlDbType.NVarChar)).Value = objurl.certissueby;
                        cmd.Parameters.Add(new SqlParameter("@criticlelinkedin", SqlDbType.NVarChar)).Value = objurl.criticlelinkedin;
                        cmd.Parameters.Add(new SqlParameter("@criticleskills", SqlDbType.NVarChar)).Value = objurl.criticleskills;
                        cmd.Parameters.Add(new SqlParameter("@criticlepreferedrole", SqlDbType.NVarChar)).Value = objurl.criticlepreferedrole;
                        cmd.Parameters.Add(new SqlParameter("@criticleauto", SqlDbType.Int)).Value = objurl.criticleauto;
                        //cmd.Parameters.Add(new SqlParameter("@flag", SqlDbType.NVarChar)).Value = objurl.Flag;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new OutputOnlyStatus
                                {
                                    
                                    Status = rdr.GetInt32(rdr.GetOrdinal("status"))


                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static async Task<ObjectResult> UpdateInterviewStatusDB(UpdateInterviewstatus objurl, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("UpdateProfileSummaryDB");
                List<OutputOnlyStatus> _ret = new List<OutputOnlyStatus>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_UpdateInterviewstatus", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.Parameters.Add(new SqlParameter("@linkedinurl", SqlDbType.NVarChar)).Value = objurl.linkedinurl;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = objurl.UserId;
                        cmd.Parameters.Add(new SqlParameter("@InterviewId", SqlDbType.Int)).Value = objurl.InterviewId;
                        //cmd.Parameters.Add(new SqlParameter("@flag", SqlDbType.NVarChar)).Value = objurl.Flag;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new OutputOnlyStatus
                                {

                                    Status = rdr.GetInt32(rdr.GetOrdinal("status"))


                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static async Task<ObjectResult> GetProfileSummaryDB(clsuserid objurl, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("get GetProfileSummaryDB");
                List<GetCuuCompanydetails> _ret = new List<GetCuuCompanydetails>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_GetProfileSummary", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.Parameters.Add(new SqlParameter("@linkedinurl", SqlDbType.NVarChar)).Value = objurl.linkedinurl;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = objurl.UserId;
                        //cmd.Parameters.Add(new SqlParameter("@flag", SqlDbType.NVarChar)).Value = objurl.Flag;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new GetCuuCompanydetails
                                {
                                    rolename = rdr.GetString(rdr.GetOrdinal("rolename")),
                                    companyname = rdr.GetString(rdr.GetOrdinal("companyname")),
                                    stmonth = rdr.GetInt32(rdr.GetOrdinal("stmonth")),
                                    styear = rdr.GetInt32(rdr.GetOrdinal("styear")),
                                    ctc = rdr.GetDecimal(rdr.GetOrdinal("ctc")),
                                    noticeperiod = rdr.GetString(rdr.GetOrdinal("noticeperiod")),
                                    IndustryType = rdr.GetString(rdr.GetOrdinal("IndustryType")),
                                    EmploymentType = rdr.GetString(rdr.GetOrdinal("EmploymentType")),
                                    Descrition = rdr.GetString(rdr.GetOrdinal("Descrition")),
                                    psummary = rdr.GetString(rdr.GetOrdinal("psummary")),
                                    status = rdr.GetInt32(rdr.GetOrdinal("status")),
                                    skills= rdr.GetString(rdr.GetOrdinal("skills")),

                                    Qualification = rdr.GetString(rdr.GetOrdinal("Qualification")),
                                    institute = rdr.GetString(rdr.GetOrdinal("institute")),
                                    passyear = rdr.GetString(rdr.GetOrdinal("passyear")),
                                    edutype = rdr.GetString(rdr.GetOrdinal("edutype")),

                                    preferedrole= rdr.GetString(rdr.GetOrdinal("preferedrole")),
                                    preferedlocation= rdr.GetString(rdr.GetOrdinal("preferedlocation")),

                                    rescountry = rdr.GetString(rdr.GetOrdinal("rescountry")),
                                    wpermit = rdr.GetString(rdr.GetOrdinal("wpermit")),
                                    nationality = rdr.GetString(rdr.GetOrdinal("nationality")),

                                    certname= rdr.GetString(rdr.GetOrdinal("certname")),
                                    certissueby = rdr.GetString(rdr.GetOrdinal("certissueby")),

                                    criticlelinkedin = "",
                                    criticleskills = rdr.GetString(rdr.GetOrdinal("skills")),
                                    criticlepreferedrole = rdr.GetString(rdr.GetOrdinal("preferedrole")),
                                    criticleauto = rdr.GetInt32(rdr.GetOrdinal("autoupdate")),
                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static async Task<ObjectResult> UpdatelinkedinurlDB(LinkedInURL objurl, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("update linkedinURL");
                List<OutputOnlyStatus> _ret = new List<OutputOnlyStatus>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_UpdatelinkedinURL", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@linkedinurl", SqlDbType.NVarChar)).Value = objurl.linkedinurl;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = objurl.Userid;
                        cmd.Parameters.Add(new SqlParameter("@flag", SqlDbType.NVarChar)).Value = objurl.Flag;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new OutputOnlyStatus
                                {
                                    Status = rdr.GetInt32(rdr.GetOrdinal("status")),


                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static async Task<ObjectResult> ValidateUserIdPassword(string UserId, string Password, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("Validating Login details");
                List<LoginResponse> _ret = new List<LoginResponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_ValidateLoginDetails", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = UserId;
                        cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.NVarChar)).Value = Password;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new LoginResponse
                                {
                                    Status = rdr.GetInt32(rdr.GetOrdinal("LoginStatus")),
                                    UserId = rdr.GetString(rdr.GetOrdinal("id")),
                                    EmailId = rdr.GetString(rdr.GetOrdinal("UserId")).Trim(),
                                    AccessToken = rdr.GetString(rdr.GetOrdinal("AccessToken")).Trim(),
                                    FullName = rdr.GetString(rdr.GetOrdinal("FullName")).Trim(),
                                    IsFirstLogin = rdr.GetInt32(rdr.GetOrdinal("IsFirstLogin")),
                                    RoleName= rdr.GetString(rdr.GetOrdinal("RoleName")).Trim(),
                                    pimg= rdr.GetString(rdr.GetOrdinal("Profilephoto")).Trim(),
                                    resume = rdr.GetString(rdr.GetOrdinal("resume")).Trim()

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }

        private static async Task<ObjectResult> InsertRegisteredUserDB(string fullname, string totexp, string hiqual, string email, string mobile, ILogger logger, IWebHostEnvironment _env)
        {
            try
            {
                
                logger.LogInformation("Insering registered user to DB");
                List<RegisterRes> _ret = new List<RegisterRes>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_CreateUser", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@fullname", SqlDbType.NVarChar)).Value = fullname;
                        cmd.Parameters.Add(new SqlParameter("@totexp", SqlDbType.NVarChar)).Value = totexp;
                        cmd.Parameters.Add(new SqlParameter("@higqua", SqlDbType.NVarChar)).Value = hiqual;
                        cmd.Parameters.Add(new SqlParameter("@email", SqlDbType.NVarChar)).Value = email;
                        cmd.Parameters.Add(new SqlParameter("@mob", SqlDbType.NVarChar)).Value = mobile;
                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new RegisterRes
                                {
                                    Status = rdr.GetInt32(rdr.GetOrdinal("LoginStatus")),
                                    UserId = rdr.GetInt32(rdr.GetOrdinal("id")),
                                    password = rdr.GetString(rdr.GetOrdinal("Password")),
                                    EmailId = rdr.GetString(rdr.GetOrdinal("UserId")).Trim(),
                                    AccessToken = rdr.GetString(rdr.GetOrdinal("AccessToken")).Trim(),
                                    FullName = rdr.GetString(rdr.GetOrdinal("FullName")).Trim(),
                                    IsFirstLogin = rdr.GetInt32(rdr.GetOrdinal("IsFirstLogin"))

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {

                throw;
            }
        }
        
            private static async Task<ObjectResult> AppliedjobsDB(string searchinput, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {
                logger.LogInformation("Getting applied jobs details");
                List<SearchJobs> _ret = new List<SearchJobs>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_APPTracking", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.NVarChar)).Value = searchinput;
                        // cmd.Parameters.Add(new SqlParameter("@location", SqlDbType.NVarChar)).Value = location;
                        //cmd.Parameters.Add(new SqlParameter("@expstatus", SqlDbType.NVarChar)).Value = expstatus;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new SearchJobs
                                {
                                    jobid= rdr.GetInt32(rdr.GetOrdinal("jobid")),
                                    TOTALAPP = rdr.GetInt32(rdr.GetOrdinal("TOTALAPP")),
                                    UR_COUNT = rdr.GetInt32(rdr.GetOrdinal("UR_COUNT")),
                                    I_COUNT = rdr.GetInt32(rdr.GetOrdinal("I_COUNT")),
                                    F_COUNT = rdr.GetInt32(rdr.GetOrdinal("F_COUNT")),
                                    Curr_mnth = rdr.GetInt32(rdr.GetOrdinal("Curr_mnth")),
                                    rolename = rdr.GetString(rdr.GetOrdinal("RoleName")).Trim(),
                                    companylogo = rdr.GetString(rdr.GetOrdinal("CompanyLogo")).Trim(),
                                    companyname = rdr.GetString(rdr.GetOrdinal("CompanyName")),
                                    PostedOn = rdr.GetString(rdr.GetOrdinal("ApplicationDate")).Trim(),
                                    Status = rdr.GetString(rdr.GetOrdinal("STATUS")).Trim(),
                                    lastUpdate = rdr.GetString(rdr.GetOrdinal("LastUpdate")),
                                    

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static async Task<ObjectResult> SearchjobsDB(string searchinput, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {
                logger.LogInformation("Getting jobs details");
                List<SearchJobs> _ret = new List<SearchJobs>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_GetSearchedJobs", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@skillset", SqlDbType.NVarChar)).Value = searchinput;
                        // cmd.Parameters.Add(new SqlParameter("@location", SqlDbType.NVarChar)).Value = location;
                        //cmd.Parameters.Add(new SqlParameter("@expstatus", SqlDbType.NVarChar)).Value = expstatus;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new SearchJobs
                                {
                                    jobid = rdr.GetInt32(rdr.GetOrdinal("jobid")),
                                    skillset = rdr.GetString(rdr.GetOrdinal("skillset")).Trim(),
                                    location = rdr.GetString(rdr.GetOrdinal("location")).Trim(),
                                    experience = rdr.GetString(rdr.GetOrdinal("experience")).Trim(),
                                    companyname = rdr.GetString(rdr.GetOrdinal("companyname")).Trim(),
                                    rolename = rdr.GetString(rdr.GetOrdinal("rolename")).Trim(),
                                    companylogo = rdr.GetString(rdr.GetOrdinal("companylogo")).Trim(),
                                    insertdate = rdr.GetDateTime(rdr.GetOrdinal("insertdate")),
                                    JobDescription = rdr.GetString(rdr.GetOrdinal("JobDescription")).Trim(),
                                    JobType = rdr.GetString(rdr.GetOrdinal("JobType")).Trim(),
                                    WorkNature = rdr.GetString(rdr.GetOrdinal("WorkNature")),
                                    PostedOn = rdr.GetString(rdr.GetOrdinal("PostedOn")),
                                    skillset2 = rdr.GetString(rdr.GetOrdinal("skillset2")),
                                    skillset3 = rdr.GetString(rdr.GetOrdinal("skillset3")),

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }

        private static async Task<ObjectResult> SearchjobsByJobIDDB(searchinputbyjobid searchinput, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {
                logger.LogInformation("Getting jobs details");
                List<SearchJobsByJobID> _ret = new List<SearchJobsByJobID>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("[SP_GetJobDetailsByJobID]", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@JobId", SqlDbType.Int)).Value = Convert.ToInt32(searchinput.SearchInput);
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = searchinput.UserId;
                        //cmd.Parameters.Add(new SqlParameter("@expstatus", SqlDbType.NVarChar)).Value = expstatus;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new SearchJobsByJobID
                                {
                                    jobid = rdr.GetInt32(rdr.GetOrdinal("JobId")),
                                    RoleName = rdr.GetString(rdr.GetOrdinal("RoleName")).Trim(),
                                    location = rdr.GetString(rdr.GetOrdinal("Location")).Trim(),
                                    PostedOn = rdr.GetString(rdr.GetOrdinal("PostedOn")).Trim(),
                                    JobType = rdr.GetString(rdr.GetOrdinal("JobType")).Trim(),
                                    WorkNature = rdr.GetString(rdr.GetOrdinal("WorkNature")).Trim(),
                                    days = rdr.GetString(rdr.GetOrdinal("days")).Trim(),
                                    deadline = rdr.GetString(rdr.GetOrdinal("deadline")),
                                    companylogo = rdr.GetString(rdr.GetOrdinal("LogoName")).Trim(),
                                    companyname = rdr.GetString(rdr.GetOrdinal("Name")).Trim(),
                                    adddress = rdr.GetString(rdr.GetOrdinal("Address")),
                                    sector = rdr.GetString(rdr.GetOrdinal("Sector")),
                                    size = rdr.GetString(rdr.GetOrdinal("size")),
                                    fyear = rdr.GetString(rdr.GetOrdinal("foundedyear")),
                                    comcul = rdr.GetString(rdr.GetOrdinal("CompanyCulture")),
                                    longdesc = rdr.GetString(rdr.GetOrdinal("LongDesc")),
                                    longdesc_2 = rdr.GetString(rdr.GetOrdinal("LongDesc_2")),
                                    longdesc_3 = rdr.GetString(rdr.GetOrdinal("LongDesc_3")),
                                    Requirments = rdr.GetString(rdr.GetOrdinal("LongRequirment")),
                                    benefit = rdr.GetString(rdr.GetOrdinal("Benefitperks")),
                                    benefitperks_health = rdr.GetString(rdr.GetOrdinal("Benefitperks_health")),
                                    benefitperks_pto = rdr.GetString(rdr.GetOrdinal("Benefitperks_pto")),
                                    benefitperks_bedge = rdr.GetString(rdr.GetOrdinal("Benefitperks_bedge")),
                                    benefitperks_remote = rdr.GetString(rdr.GetOrdinal("Benefitperks_remote")),
                                    benefitperks_eve = rdr.GetString(rdr.GetOrdinal("Benefitperks_eve")),
                                    appliedcount = rdr.GetInt32(rdr.GetOrdinal("appliedcount")),
                                    ctc = rdr.GetString(rdr.GetOrdinal("ctc")),
                                    applystatus= rdr.GetInt32(rdr.GetOrdinal("applystatus")),
                                    applydate= rdr.GetString(rdr.GetOrdinal("applydate"))

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }

        private static async Task<ObjectResult> InsertJobApplicationsDB(JobApplicationInput searchinput, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {
                logger.LogInformation("inserting jobs application");
                List<RegistraionResponse> _ret = new List<RegistraionResponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("[SP_InsertUsersJobApplication]", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@JobId", SqlDbType.Int)).Value = Convert.ToInt32(searchinput.JobId);
                        cmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.NVarChar)).Value = Convert.ToString(searchinput.UserId);
                        cmd.Parameters.Add(new SqlParameter("@AppType", SqlDbType.NVarChar)).Value = Convert.ToString(searchinput.AppType);

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new RegistraionResponse
                                {
                                    result = rdr.GetString(rdr.GetOrdinal("STATUS")),

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }

        private static async Task<ObjectResult> ChangePasswordDB(string UserId, string CurrPassword, string NewPassword, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("change password");
                List<LoginResponse> _ret = new List<LoginResponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_ChangePassword", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = UserId;
                        cmd.Parameters.Add(new SqlParameter("@CurrPass", SqlDbType.NVarChar)).Value = CurrPassword;
                        cmd.Parameters.Add(new SqlParameter("@NewPass", SqlDbType.NVarChar)).Value = NewPassword;


                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new LoginResponse
                                {
                                    Status = rdr.GetInt32(rdr.GetOrdinal("Status")),



                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }

        
       private static async Task<ObjectResult> GetAutoCompleteSearchDB(string searchinput, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("GetAutoCompleteSearchDB");
                List<autocompleteresponse> _ret = new List<autocompleteresponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_GetAutoCompleteSearch", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@searchinput", SqlDbType.NVarChar)).Value = searchinput;



                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new autocompleteresponse
                                {
                                    
                                    _output = rdr.GetString(rdr.GetOrdinal("Searchvalues")),
                                    



                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }


        private static async Task<ObjectResult> ResetPasswordDB(string EmailId, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("reset password");
                List<ResetPassRes> _ret = new List<ResetPassRes>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_ResetPassword", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@EmailId", SqlDbType.NVarChar)).Value = EmailId;



                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new ResetPassRes
                                {
                                    Status = rdr.GetInt32(rdr.GetOrdinal("status")),
                                    EmailId = rdr.GetString(rdr.GetOrdinal("UserID")),
                                    Password = rdr.GetString(rdr.GetOrdinal("Password"))



                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static async Task<ObjectResult> GetUserDetailsDB(string usrid, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("reset password");
                List<updateuserRes> _ret = new List<updateuserRes>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_GetUserBasicDetails", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = usrid;



                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new updateuserRes
                                {
                                    FullName = rdr.GetString(rdr.GetOrdinal("FullName")),
                                    RoleName = rdr.GetString(rdr.GetOrdinal("RoleName")),
                                    TotExp = rdr.GetString(rdr.GetOrdinal("TotExp")),
                                    ctc = rdr.GetString(rdr.GetOrdinal("ctc")),
                                    noticeperiod = rdr.GetString(rdr.GetOrdinal("noticeperiod")),
                                    Profilephoto = rdr.GetString(rdr.GetOrdinal("Profilephoto")),
                                    linkedinurl= rdr.GetString(rdr.GetOrdinal("linkedinurl")),
                                    MobileNo= rdr.GetString(rdr.GetOrdinal("MobileNo"))

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        

             private static async Task<ObjectResult> GetUserresumeDB(string usrid, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("reset password");
                List<getuserprofilepic> _ret = new List<getuserprofilepic>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_GetUserresume", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = usrid;



                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new getuserprofilepic
                                {

                                    Profilephoto = rdr.GetString(rdr.GetOrdinal("resume"))


                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }

        private static async Task<ObjectResult> GetUserprofilepicDB(string usrid, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("reset password");
                List<getuserprofilepic> _ret = new List<getuserprofilepic>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_GetUsercurrprofilepic", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = usrid;



                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new getuserprofilepic
                                {
                                    
                                    Profilephoto = rdr.GetString(rdr.GetOrdinal("Profilephoto"))


                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        
        private static async Task<ObjectResult> UpdateUserDetailsDB(updateuserbasicdetails usr, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("update profile");
                List<RegistraionResponse> _ret = new List<RegistraionResponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_Updatebasicdetails", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = usr.UserId;
                        cmd.Parameters.Add(new SqlParameter("@pphoto", SqlDbType.NVarChar)).Value = usr.pphoto;
                        cmd.Parameters.Add(new SqlParameter("@fullname", SqlDbType.NVarChar)).Value = usr.fullname;
                        cmd.Parameters.Add(new SqlParameter("@Role", SqlDbType.NVarChar)).Value = usr.Role;
                        cmd.Parameters.Add(new SqlParameter("@totexp", SqlDbType.NVarChar)).Value = usr.totexp;
                        cmd.Parameters.Add(new SqlParameter("@ctc", SqlDbType.NVarChar)).Value = usr.ctc;
                        cmd.Parameters.Add(new SqlParameter("@nperiod", SqlDbType.NVarChar)).Value = usr.nperiod;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new RegistraionResponse
                                {
                                    
                                    result = rdr.GetString(rdr.GetOrdinal("result")),
                                    
                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        

        private static async Task<ObjectResult> UpdateUserresumeDB(Updateprofilepic usr, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("update profile");
                List<RegistraionResponse> _ret = new List<RegistraionResponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_Updateresume", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = usr.UserId;
                        cmd.Parameters.Add(new SqlParameter("@pphoto", SqlDbType.NVarChar)).Value = usr.pphoto;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new RegistraionResponse
                                {

                                    result = rdr.GetString(rdr.GetOrdinal("result")),

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static async Task<ObjectResult> UpdateUserDetailsppDB(Updateprofilepic usr, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("update profile");
                List<RegistraionResponse> _ret = new List<RegistraionResponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("SP_Updateprofilepic", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = usr.UserId;
                        cmd.Parameters.Add(new SqlParameter("@pphoto", SqlDbType.NVarChar)).Value = usr.pphoto;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new RegistraionResponse
                                {

                                    result = rdr.GetString(rdr.GetOrdinal("result")),

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        private static string encodebase64(string plaintext)
        {
            byte[] plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plaintext);
            return Convert.ToBase64String(plainTextBytes);
        }

    
private static string decodebase64(string strbase64)
        {
            byte[] decodedBytes = Convert.FromBase64String(strbase64);
            return Encoding.UTF8.GetString(decodedBytes);
        }

    }
}

