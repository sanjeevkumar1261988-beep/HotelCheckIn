﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ElightRecruitmentAPI.Helpers
{

    public static  class Globals
    {
        //public static string _webconnstring = Startup.GetValue<string>("ConnectionStrings:DBConn");
    }
}
