﻿
using ElightRecruitmentAPI.Models;
using Microsoft.Extensions.Options;
using System.IO;
using System.Threading.Tasks;

namespace ElightRecruitmentAPI.Helpers
{
    public class ConfigurationHelper
    {
       
    }
}
