﻿using CareerSphareAPI.Models;
using ElightRecruitmentAPI.Helpers;
using ElightRecruitmentAPI.Models;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using MimeKit;
using System.Data;
using System.Net;
//using System.Net.Mail;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Hosting;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using System.Net;
using System.Text;
using CareerSphareAPI.Models;
namespace CareerSphareAPI.Helpers
{
    public class HotelHelper
    {

        public static async Task<ObjectResult> InsertRegisteredUser(string hname, string mobile, string email, ILogger logger, IWebHostEnvironment _env)
        {
            if (string.IsNullOrEmpty(hname) || string.IsNullOrEmpty(mobile)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await InsertRegisteredUserDB(hname, mobile, email, logger, _env);
            if (DBoutput.StatusCode == 200)
            {
                List<RegisterRes> _outputDB = (List<RegisterRes>)DBoutput.Value;
                if (_outputDB[0].UserId != 0)
                {

                    MailerHotel.RegistrationMail(_env, email, _outputDB[0].password);
                }
            }
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        private static async Task<ObjectResult> InsertRegisteredUserDB(string hname,string mobile,string email, ILogger logger, IWebHostEnvironment _env)
        {
            try
            {

                logger.LogInformation("Insering registered user to DB");
                List<RegisterRes> _ret = new List<RegisterRes>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("Hotel_SP_CreateUser", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@hname", SqlDbType.NVarChar)).Value = hname;
                        cmd.Parameters.Add(new SqlParameter("@email", SqlDbType.NVarChar)).Value = email;
                        cmd.Parameters.Add(new SqlParameter("@mob", SqlDbType.NVarChar)).Value = mobile;
                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new RegisterRes
                                {
                                    Status = rdr.GetInt32(rdr.GetOrdinal("LoginStatus")),
                                    UserId = rdr.GetInt32(rdr.GetOrdinal("HID")),
                                    password = rdr.GetString(rdr.GetOrdinal("Password")),
                                    EmailId = rdr.GetString(rdr.GetOrdinal("email")).Trim(),
                                    AccessToken = rdr.GetString(rdr.GetOrdinal("AccessToken")).Trim(),
                                    FullName = rdr.GetString(rdr.GetOrdinal("Name")).Trim(),
                                    IsFirstLogin = rdr.GetInt32(rdr.GetOrdinal("IsFirstLogin"))

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public static async Task<ObjectResult> LoginRegisteredUser(string UserId, string Password, ILogger logger, IWebHostEnvironment _env)
        {
            if (string.IsNullOrEmpty(UserId) || string.IsNullOrEmpty(Password)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await ValidateUserIdPassword(UserId, Password, logger, _env);
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        private static async Task<ObjectResult> ValidateUserIdPassword(string UserId, string Password, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("Validating Login details");
                List<LoginResponse> _ret = new List<LoginResponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("Hotel_SP_ValidateLoginDetails", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.NVarChar)).Value = UserId;
                        cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.NVarChar)).Value = Password;

                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new LoginResponse
                                {
                                    Status = rdr.GetInt32(rdr.GetOrdinal("LoginStatus")),
                                    UserId = rdr.GetString(rdr.GetOrdinal("id")),
                                    EmailId = rdr.GetString(rdr.GetOrdinal("email")).Trim(),
                                    AccessToken = rdr.GetString(rdr.GetOrdinal("AccessToken")).Trim(),
                                    FullName = rdr.GetString(rdr.GetOrdinal("Name")).Trim(),
                                    IsFirstLogin = rdr.GetInt32(rdr.GetOrdinal("IsFirstLogin")),
                                    pimg = rdr.GetString(rdr.GetOrdinal("Profilephoto")).Trim()
                                    

                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }
        public static async Task<ObjectResult> ChangePassword(int hid, string Password, string NewPassword, ILogger logger, IWebHostEnvironment _env)
        {
            if (string.IsNullOrEmpty(Password)) return new ObjectResult("Please fill the details first") { StatusCode = 400 };
            var DBoutput = await ChangePasswordDB(hid, Password, NewPassword, logger, _env);
            //if (DBoutput.StatusCode == 200 && Password !="R")
            //{
            //    List<ResetPassRes> _outputDB = (List<ResetPassRes>)DBoutput.Value;
            //    if (_outputDB[0].Status != 0)
            //    {

            //        Mailer.PushEmailResetPassword(_env, _outputDB[0].EmailId, _outputDB[0].Password);
            //    }

            //}
            return new ObjectResult(DBoutput.Value) { StatusCode = 200 };
        }
        private static async Task<ObjectResult> ChangePasswordDB(int UserId, string CurrPassword, string NewPassword, ILogger logger, IWebHostEnvironment _env)
        {

            try
            {

                logger.LogInformation("change password");
                List<LoginResponse> _ret = new List<LoginResponse>();

                using (SqlConnection cnn = new SqlConnection("Server=162.222.225.88;Initial Catalog=careersphare;User ID=CS_Admin;Password=CareerSph@re#@222;MultipleActiveResultSets=True;Persist Security Info=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;"))
                //using (SqlConnection cnn = new SqlConnection(_Connstring))
                {
                    await cnn.OpenAsync();
                    if (cnn.State != ConnectionState.Open)
                    {
                        await cnn.CloseAsync();
                        await cnn.OpenAsync();
                    }
                    using (SqlCommand cmd = new SqlCommand("Hotel_SP_ChangePassword", cnn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int)).Value = UserId;
                        cmd.Parameters.Add(new SqlParameter("@CurrPass", SqlDbType.NVarChar)).Value = CurrPassword;
                        cmd.Parameters.Add(new SqlParameter("@NewPass", SqlDbType.NVarChar)).Value = NewPassword;


                        using (SqlDataReader rdr = await cmd.ExecuteReaderAsync())
                        {
                            // iterate through results, printing each to console
                            while (await rdr.ReadAsync())
                            {
                                _ret.Add(new LoginResponse
                                {
                                    Status = rdr.GetInt32(rdr.GetOrdinal("Status")),



                                });
                            }
                        }
                    }


                }

                if (_ret is null) return new ObjectResult(null) { StatusCode = 400 };
                return new ObjectResult(_ret) { StatusCode = 200 };




            }
            catch (Exception ex)
            {


                return new ObjectResult(null) { StatusCode = 400 };
                throw;
            }
        }

    }
}
