var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpClient();
builder.Services.AddCors(options => {
    options.AddPolicy("MyPolicy", builder => {
        builder.AllowAnyOrigin()
               .AllowAnyMethod() // Or specify allowed methods like .AllowMethods("GET", "POST")
               .AllowAnyHeader(); // Or specify allowed headers
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.

    app.UseSwagger();
    app.UseSwaggerUI();
app.UseStaticFiles();
app.UseCors("MyPolicy"); // Apply the policy
app.UseHttpsRedirection();
app.UseAuthorization();

app.MapControllers();

app.Run();
