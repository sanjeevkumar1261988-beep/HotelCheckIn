﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class ResetPassRes
    {
        [JsonPropertyName("EmailId")]
        public string EmailId { get; set; }

        [JsonPropertyName("Password")]
        public string Password { get; set; }

        [JsonPropertyName("Status")]
        public int Status { get; set; }

    }
}
