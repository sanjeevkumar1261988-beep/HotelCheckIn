﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class ContactUs
    {
        [JsonPropertyName("FirstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("LastName")]
        public string LastName { get; set; }

        [JsonPropertyName("Emailid")]
        public string Emailid { get; set; }

        [JsonPropertyName("MobileNo")]
        public string MobileNo { get; set; }

        [JsonPropertyName("Message")]
        public string Message { get; set; }
    }
}
