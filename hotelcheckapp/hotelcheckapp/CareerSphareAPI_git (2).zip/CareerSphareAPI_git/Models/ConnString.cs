﻿namespace ElightRecruitmentAPI.Models
{
    public class ConnString
    {
        public string DefaultConnection { get; set; }
    }
}
