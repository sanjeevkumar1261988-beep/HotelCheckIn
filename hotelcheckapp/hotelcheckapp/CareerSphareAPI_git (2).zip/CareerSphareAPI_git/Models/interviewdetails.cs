﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class interviewdetails
    {
        [JsonPropertyName("RoleName")]
        public string RoleName { get; set; }

        [JsonPropertyName("InterviewId")]
        public int InterviewId { get; set; }

        [JsonPropertyName("JobId")]
        public int JobId { get; set; }

        [JsonPropertyName("Interviewstatus")]
        public string Interviewstatus { get; set; }

        [JsonPropertyName("InterviewDate")]
        public string InterviewDate { get; set; }

        [JsonPropertyName("InterviewLocation")]
        public string InterviewLocation { get; set; }

        [JsonPropertyName("InterviewConfirmstatus")]
        public int InterviewConfirmstatus { get; set; }

        [JsonPropertyName("Name")]
        public string Name { get; set; }

        [JsonPropertyName("LogoName")]
        public string LogoName { get; set; }
    }
}
