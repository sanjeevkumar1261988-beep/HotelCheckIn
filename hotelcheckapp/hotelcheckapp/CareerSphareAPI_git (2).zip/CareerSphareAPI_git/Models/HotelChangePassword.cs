﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class HotelChangePassword
    {

        [JsonPropertyName("UserId")]
        public int HId { get; set; }

        [JsonPropertyName("CurrentPassword")]
        public string CurrentPassword { get; set; }

        [JsonPropertyName("password")]
        public string password { get; set; }
    }
}
