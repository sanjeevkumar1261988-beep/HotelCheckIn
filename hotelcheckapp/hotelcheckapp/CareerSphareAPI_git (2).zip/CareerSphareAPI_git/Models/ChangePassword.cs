﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class ChangePassword
    {

        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

        [JsonPropertyName("CurrentPassword")]
        public string CurrentPassword { get; set; }

        [JsonPropertyName("password")]
        public string password { get; set; }

        [JsonPropertyName("confirmPassword")]
        public string confirmPassword { get; set; }
    }
}
