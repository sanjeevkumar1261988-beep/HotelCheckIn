﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class EmployerRegistration
    {
        [JsonPropertyName("fullName")]
        public string fullName { get; set; }

        [JsonPropertyName("cname")]
        public string cname { get; set; }


        [JsonPropertyName("email")]
        public string email { get; set; }


        [JsonPropertyName("mobile")]
        public Int64 mobile { get; set; }
    }
}
