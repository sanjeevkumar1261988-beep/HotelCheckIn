﻿namespace ElightRecruitmentAPI.Models
{
    public class AppSettings
    {
        public static string? ConnString { get; set; }

    }
}
