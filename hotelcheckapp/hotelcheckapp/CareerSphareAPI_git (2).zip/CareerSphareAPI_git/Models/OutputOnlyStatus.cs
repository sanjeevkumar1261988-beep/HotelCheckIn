﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class OutputOnlyStatus
    {
        [JsonPropertyName("Status")]
        public int Status { get; set; }
    }
}
