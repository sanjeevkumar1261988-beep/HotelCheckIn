﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class GetCuuCompanydetails
    {
        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

        [JsonPropertyName("rolename")]
        public string rolename { get; set; }

        [JsonPropertyName("companyname")]
        public string companyname { get; set; }

        [JsonPropertyName("stmonth")]
        public int stmonth { get; set; }

        [JsonPropertyName("styear")]
        public int styear { get; set; }

        [JsonPropertyName("ctc")]
        public decimal ctc { get; set; }

        [JsonPropertyName("noticeperiod")]
        public string noticeperiod { get; set; }

        [JsonPropertyName("IndustryType")]
        public string IndustryType { get; set; }

        [JsonPropertyName("EmploymentType")]
        public string EmploymentType { get; set; }

        [JsonPropertyName("Descrition")]
        public string Descrition { get; set; }

        [JsonPropertyName("psummary")]
        public string psummary { get; set; }

        [JsonPropertyName("status")]
        public int status { get; set; }

        [JsonPropertyName("skills")]
        public string skills { get; set; }

        [JsonPropertyName("Qualification")]
        public string Qualification { get; set; }

        [JsonPropertyName("institute")]
        public string institute { get; set; }

        [JsonPropertyName("passyear")]
        public string passyear { get; set; }

        [JsonPropertyName("edutype")]
        public string edutype { get; set; }

        [JsonPropertyName("preferedrole")]
        public string preferedrole { get; set; }

        [JsonPropertyName("preferedlocation")]
        public string preferedlocation { get; set; }

        [JsonPropertyName("rescountry")]
        public string rescountry { get; set; }

        [JsonPropertyName("wpermit")]
        public string wpermit { get; set; }

        [JsonPropertyName("nationality")]
        public string nationality { get; set; }

        [JsonPropertyName("certname")]
        public string certname { get; set; }

        [JsonPropertyName("certissueby")]
        public string certissueby { get; set; }

        [JsonPropertyName("criticlelinkedin")]
        public string criticlelinkedin { get; set; }

        [JsonPropertyName("criticleskills")]
        public string criticleskills { get; set; }

        [JsonPropertyName("criticlepreferedrole")]
        public string criticlepreferedrole { get; set; }

        [JsonPropertyName("criticleauto")]
        public int criticleauto { get; set; }

        
            
    }
}
