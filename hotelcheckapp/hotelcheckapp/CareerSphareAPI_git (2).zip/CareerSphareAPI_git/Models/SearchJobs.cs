﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class SearchJobs
    {
        [JsonPropertyName("jobid")]
        public Int32 jobid { get; set; }

        [JsonPropertyName("skillset")]
        public string skillset { get; set; }

        [JsonPropertyName("location")]
        public string location { get; set; }

        [JsonPropertyName("experience")]
        public string experience { get; set; }

        [JsonPropertyName("companyname")]
        public string companyname { get; set; }
        
        [JsonPropertyName("rolename")]
        public string rolename { get; set; }

        [JsonPropertyName("companylogo")]
        public string companylogo { get; set; }

        [JsonPropertyName("insertdate")]
        public DateTime insertdate { get; set; }

        [JsonPropertyName("JobDescription")]
        public string JobDescription { get; set; }

        [JsonPropertyName("JobType")]
        public string JobType { get; set; }

        [JsonPropertyName("WorkNature")]
        public string WorkNature { get; set; }

        [JsonPropertyName("PostedOn")]
        public string PostedOn { get; set; }
        [JsonPropertyName("skillset2")]
        public string skillset2 { get; set; }
        [JsonPropertyName("skillset3")]
        public string skillset3 { get; set; }
        [JsonPropertyName("TOTALAPP")]
        public int TOTALAPP { get; set; }

        [JsonPropertyName("UR_COUNT")]
        public int UR_COUNT { get; set; }

        [JsonPropertyName("I_COUNT")]
        public int I_COUNT { get; set; }

        [JsonPropertyName("F_COUNT")]
        public int F_COUNT { get; set; }
        [JsonPropertyName("Curr_mnth")]
        public int Curr_mnth { get; set; }

        [JsonPropertyName("lastUpdate")]
        public string lastUpdate { get; set; }

        [JsonPropertyName("Status")]
        public string Status { get; set; }

    }
}
