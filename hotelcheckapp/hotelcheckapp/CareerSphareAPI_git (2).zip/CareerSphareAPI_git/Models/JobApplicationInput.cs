﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class JobApplicationInput
    {
        [JsonPropertyName("JobId")]
        public int JobId { get; set; }

        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

        [JsonPropertyName("UserEmail")]
        public string UserEmail { get; set; }

        [JsonPropertyName("AppType")]
        public string AppType { get; set; }

    }
}
