﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class Services
    {
            [JsonPropertyName("ServiceID")]
            public Int32 ServiceID { get; set; }

            [JsonPropertyName("ServiceName")]
            public string ServiceName { get; set; }

            [JsonPropertyName("DiscountInPercent")]
            public string DiscountInPercent { get; set; }

            [JsonPropertyName("OldPrice")]
            public decimal OldPrice { get; set; }

            [JsonPropertyName("ActualPrice")]
            public decimal ActualPrice { get; set; }

            [JsonPropertyName("CGSTinPercent")]
            public string CGSTinPercent { get; set; }

            [JsonPropertyName("SGSTinPercent")]
            public string SGSTinPercent { get; set; }

            [JsonPropertyName("FinalPriceafterTax")]
            public decimal FinalPriceafterTax { get; set; }
            
            [JsonPropertyName("CurrencyType")]
            public string CurrencyType { get; set; }
        




    }
    }
