﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    
    public class RegistrationInput
    {
        [JsonPropertyName("fullName")]
        public string fullName { get; set; }        
       
        [JsonPropertyName("experience")]
        public string experience { get; set; } 

        
        [JsonPropertyName("highestQualifiation")]
        public string highestQualifiation { get; set; } 

        
        [JsonPropertyName("email")]
        public string email { get; set; } 

        
        [JsonPropertyName("mobile")]
        public Int64 mobile { get; set; } 
    }
}
