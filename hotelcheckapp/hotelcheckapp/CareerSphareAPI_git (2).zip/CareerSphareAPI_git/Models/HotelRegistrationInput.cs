﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    
    public class HotelRegistrationInput
    {
        [JsonPropertyName("hName")]
        public string hName { get; set; }

        [JsonPropertyName("mobile")]
        public string mobile { get; set; }

        [JsonPropertyName("email")]
        public string email { get; set; } 

        
         
    }
}
