﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class SearchJobsByJobID
    {
        [JsonPropertyName("Id")]
        public Int32 Id { get; set; }

        [JsonPropertyName("jobid")]
        public Int32 jobid { get; set; }

        [JsonPropertyName("RoleName")]
        public string RoleName { get; set; }

        [JsonPropertyName("location")]
        public string location { get; set; }

        [JsonPropertyName("WorkNature")]
        public string WorkNature { get; set; }

        [JsonPropertyName("companyname")]
        public string companyname { get; set; }

        [JsonPropertyName("companylogo")]
        public string companylogo { get; set; }

        [JsonPropertyName("deadline")]
        public string deadline { get; set; }
        

        [JsonPropertyName("JobType")]
        public string JobType { get; set; }

        [JsonPropertyName("PostedOn")]
        public string PostedOn { get; set; }

        [JsonPropertyName("adddress")]
        public string adddress { get; set; }

        [JsonPropertyName("days")]
        public string days { get; set; }

        [JsonPropertyName("WorkType")]
        public string WorkType { get; set; }

        [JsonPropertyName("sector")]
        public string sector { get; set; }

        [JsonPropertyName("size")]
        public string size { get; set; }

        [JsonPropertyName("fyear")]
        public string fyear { get; set; }

        [JsonPropertyName("comcul")]
        public string comcul { get; set; }

        [JsonPropertyName("longdesc")]
        public string longdesc { get; set; }

        [JsonPropertyName("longdesc_2")]
        public string longdesc_2 { get; set; }

        [JsonPropertyName("longdesc_3")]
        public string longdesc_3 { get; set; }

        

        [JsonPropertyName("Requirments")]
        public string Requirments { get; set; }

        [JsonPropertyName("benefit")]
        public string benefit { get; set; }

        [JsonPropertyName("benefitperks_health")]
        public string benefitperks_health { get; set; }

        [JsonPropertyName("benefitperks_pto")]
        public string benefitperks_pto { get; set; }

        [JsonPropertyName("benefitperks_bedge")]
        public string benefitperks_bedge { get; set; }

        [JsonPropertyName("benefitperks_remote")]
        public string benefitperks_remote { get; set; }

        [JsonPropertyName("benefitperks_eve")]
        public string benefitperks_eve { get; set; }
        [JsonPropertyName("appliedcount")]
        public int @appliedcount { get; set; }

        [JsonPropertyName("ctc")]
        public string ctc { get; set; }

        [JsonPropertyName("applystatus")]
        public int applystatus { get; set; }

        [JsonPropertyName("applydate")]
        public string applydate { get; set; }

    }
}
