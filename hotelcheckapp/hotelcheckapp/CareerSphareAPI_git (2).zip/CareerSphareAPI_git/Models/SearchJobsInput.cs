﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class SearchJobsInput
    {
        [JsonPropertyName("SearchInput")]
        public string SearchInput { get; set; }

       

    }
}
