﻿using System;
using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class updateuserbasicdetails
    {
        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

        [JsonPropertyName("pphoto")]
        public string pphoto { get; set; }

        [JsonPropertyName("fullname")]
        public string fullname { get; set; }


        [JsonPropertyName("Role")]
        public string Role { get; set; }


        [JsonPropertyName("totexp")]
        public string totexp { get; set; }


        [JsonPropertyName("ctc")]
        public string ctc { get; set; }

        [JsonPropertyName("nperiod")]
        public string nperiod { get; set; }

    }
}
