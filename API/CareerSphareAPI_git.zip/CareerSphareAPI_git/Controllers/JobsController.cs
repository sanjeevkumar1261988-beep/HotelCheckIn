﻿using ElightRecruitmentAPI.Helpers;
using ElightRecruitmentAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CareerSphareAPI.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [ApiVersion("1")]
    [Route("api/v1/")]
    [AllowAnonymous]
    public class JobsController : ControllerBase
    {
        private readonly ILogger<JobsController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public JobsController(ILogger<JobsController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;

        }
        [HttpGet("PaidServices")]
        public async Task<IActionResult> GetPaidServices()
        {
            return await JobsServicesHelper.GetPaidServices(_logger, _webHostEnvironment);
        }
        [HttpPost("PushContactUs")]
        public async Task<IActionResult> InsertContactUs([FromBody] ContactUs _contect)
        {
            return await ContactUsHelper.InsertContactUs(_contect, _logger, _webHostEnvironment);
        }
    }
}
