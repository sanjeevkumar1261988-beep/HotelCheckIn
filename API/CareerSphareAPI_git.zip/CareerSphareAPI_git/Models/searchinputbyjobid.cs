﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class searchinputbyjobid
    {
        [JsonPropertyName("SearchInput")]
        public string SearchInput { get; set; }

        [JsonPropertyName("UserId")]
        public string UserId { get; set; }
    }
}
