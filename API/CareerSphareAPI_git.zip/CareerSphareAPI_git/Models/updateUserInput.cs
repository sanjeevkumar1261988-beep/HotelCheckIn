﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class updateUserInput
    {
        [JsonPropertyName("UserId")]
        public string UserId { get; set; }
    }
}
