﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class LoginResponse
    {
        [JsonPropertyName("Status")]
        public Int32 Status { get; set; }

        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

        [JsonPropertyName("EmailId")]
        public string EmailId { get; set; }

        [JsonPropertyName("AccessToken")]
        public string AccessToken { get; set; }

        [JsonPropertyName("FullName")]
        public string FullName { get; set; }
        [JsonPropertyName("IsFirstLogin")]
        public Int32 IsFirstLogin { get; set; }
        [JsonPropertyName("RoleName")]
        public string RoleName { get; set; }

        [JsonPropertyName("pimg")]
        public string pimg { get; set; }

        [JsonPropertyName("resume")]
        public string resume { get; set; }
    }
}
