﻿namespace ElightRecruitmentAPI.Models
{
    public class autocompleteresponse
    {
        public string _output { get; set; }
    }
}
