﻿using System;
using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class updateuserRes
    {
        [JsonPropertyName("FullName")]
        public string FullName { get; set; }

        [JsonPropertyName("RoleName")]
        public string RoleName { get; set; }

        [JsonPropertyName("TotExp")]
        public string TotExp { get; set; }


        [JsonPropertyName("ctc")]
        public string ctc { get; set; }


        [JsonPropertyName("noticeperiod")]
        public string noticeperiod { get; set; }


        [JsonPropertyName("Profilephoto")]
        public string Profilephoto { get; set; }
        [JsonPropertyName("linkedinurl")]
        public string linkedinurl { get; set; }

        [JsonPropertyName("MobileNo")]
        public string MobileNo { get; set; }
        

    }
}
