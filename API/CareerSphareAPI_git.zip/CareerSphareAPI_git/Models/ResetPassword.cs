﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class ResetPassword
    {
        [JsonPropertyName("EmailId")]
        public string EmailId { get; set; }
    }
}
