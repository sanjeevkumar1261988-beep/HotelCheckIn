﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class LinkedInURL
    {
        [JsonPropertyName("linkedinurl")]
        public string linkedinurl { get; set; }

        [JsonPropertyName("Userid")]
        public string Userid { get; set; }
        [JsonPropertyName("Flag")]
        public string Flag { get; set; }
    }
}
