﻿using Azure.Core.Serialization;
using System;
using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class RegistraionResponse
    {

        [JsonPropertyName("result")]
        public string result { get; set; }

        
    }
}
