﻿using System.Text.Json.Serialization;
namespace CareerSphareAPI.Models
{
    public class getuserprofilepic
    {
        
            [JsonPropertyName("Profilephoto")]
        public string Profilephoto { get; set; }
    }
}
