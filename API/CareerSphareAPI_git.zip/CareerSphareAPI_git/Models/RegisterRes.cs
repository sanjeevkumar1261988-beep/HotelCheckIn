﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class RegisterRes
    {
        [JsonPropertyName("Status")]
        public Int32 Status { get; set; }

        [JsonPropertyName("UserId")]
        public Int32 UserId { get; set; }

        [JsonPropertyName("password")]
        public string password { get; set; }

        [JsonPropertyName("EmailId")]
        public string EmailId { get; set; }

        [JsonPropertyName("AccessToken")]
        public string AccessToken { get; set; }

        [JsonPropertyName("FullName")]
        public string FullName { get; set; }
        [JsonPropertyName("IsFirstLogin")]
        public Int32 IsFirstLogin { get; set; }
        
    }
}
