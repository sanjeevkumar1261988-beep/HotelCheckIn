﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class Updateprofilepic
    {
        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

        [JsonPropertyName("pphoto")]
        public string pphoto { get; set; }

    }
}
