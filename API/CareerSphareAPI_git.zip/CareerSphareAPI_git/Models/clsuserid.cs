﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class clsuserid
    {
        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

    }
}
