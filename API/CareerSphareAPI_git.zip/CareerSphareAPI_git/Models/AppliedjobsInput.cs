﻿using System.Text.Json.Serialization;

namespace ElightRecruitmentAPI.Models
{
    public class AppliedjobsInput
    {
        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

    }
}
