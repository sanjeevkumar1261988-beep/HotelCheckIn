﻿using System.Text.Json.Serialization;

namespace CareerSphareAPI.Models
{
    public class UpdateInterviewstatus
    {
        [JsonPropertyName("UserId")]
        public string UserId { get; set; }

        [JsonPropertyName("InterviewId")]
        public int InterviewId { get; set; }
    }
}
